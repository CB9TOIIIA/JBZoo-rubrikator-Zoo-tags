<div id="rubrikator" class="<?php echo $moduleclass_sfx ?>">
<?php
if ($params['title1'] !='') {
echo "<a href='/tag/". $params['title1'] . ".html'>". $params['title1'] ."</a> "  ;
}
if ($params['title2'] !='') {
echo "<a href='/tag/". $params['title2'] . ".html'>". $params['title2'] ."</a> "  ;
}
if ($params['title3'] !='') {
echo "<a href='/tag/". $params['title3'] . ".html'>". $params['title3'] ."</a> "  ;
}
if ($params['title4'] !='') {
echo "<a href='/tag/". $params['title4'] . ".html'>". $params['title4'] ."</a> "  ;
}
if ($params['title5'] !='') {
echo "<a href='/tag/". $params['title5'] . ".html'>". $params['title5'] ."</a> "  ;
}
if ($params['title6'] !='') {
echo "<a href='/tag/". $params['title6'] . ".html'>". $params['title6'] ."</a> "  ;
}
if ($params['title7'] !='') {
echo "<a href='/tag/". $params['title7'] . ".html'>". $params['title7'] ."</a> "  ;
}
if ($params['title8'] !='') {
echo "<a href='/tag/". $params['title8'] . ".html'>". $params['title8'] ."</a> "  ;
}
if ($params['title9'] !='') {
echo "<a href='/tag/". $params['title9'] . ".html'>". $params['title9'] ."</a> "  ;
}
if ($params['title10'] !='') {
echo "<a href='/tag/". $params['title10'] . ".html'>". $params['title10'] ."</a> "  ;
}

?>
</div>